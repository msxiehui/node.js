/**
 * Created by UPC on 2017/7/16.
 */
var request = require('superagent');
var mkdirp = require('mkdirp');
var schedule = require('node-schedule');
var mytool = require('./src/myTools.js');
var email = require('./src/email.js');
var fs = require("fs");


var Count=1000;
var Num=0;
var secondNum=0;
var secondArr=[];
var isReset=false;
var isStop=false;
var isFen=false;

var rule1 = new schedule.RecurrenceRule();
rule1.second = [1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49,51,53,55,57,59];

var rule2 = new schedule.RecurrenceRule();
rule2.second =  1;


getCount();

schedule.scheduleJob("0 0 1 * * *", function(){
    getCount();
})


var SecondSchedul=schedule.scheduleJob(rule1, function(){
    console.log(mytool.getNowFormatDate())
    if(secondArr.indexOf(new Date().getSeconds())!=-1){
        Push();
    }
    if(secondNum<1 && isFen==false){
        writeLog("修改执行时间为每分钟执行一次")
        SecondSchedul.reschedule(rule2);
        isReset=true;
        isFen=true;
    }else{
        if(isReset==true){

            writeLog("恢复2秒执行一次")
            SecondSchedul.reschedule(rule1);
            isFen = false;
            isReset=false;
        }
    }
})


// schedule.scheduleJob(rule2, function(){
//     secondNum=Math.floor(Num/60);
//     secondArr=getRandomArrayElements(rule1.second,secondNum);
//     console.log("秒："+secondNum)
//     console.log("刷新点：",secondArr)
//     if(isStop){
//         console.log(mytool.getNowFormatDate())
//         console.log("回复执行-分钟")
//         SecondSchedul.reschedule(rule2);
//         isStop=false;
//         isReset=true;
//     }
//
// })




function Push() {
    if(Num<=0){
        writeLog("当前小时已经没有数据")
        return;
    }

    writeLog("Push："+mytool.getNowFormatDate())
    Num--;
    Count--;
    writeLog("当前小时已发送/剩余数量："+Num+"/"+Count)
    // SecondSchedul.cancel();
    // console.error("停止执行器")
    //  console.log()
    //
    // isStop=true;
}



//总秒数
var s=14*60*60;



var GetAgin=0;

 function  getCount() {

    email.toEmail("今天提交总数："+Count,"通知");

     var D=24-new Date().getHours();
     if(D>0){
         Num=Math.floor(Count/D)+mytool.rand(10,100);
         secondNum=Math.floor(Num/60);
         secondArr=getRandomArrayElements(rule1.second,secondNum);
     }
     writeLog("今天提交总数:"+Count)


     return;
    request
        .get('http://itapi.demo.iforce-media.com/a/v1/push/PushCount')
        .timeout({
            response: 5000,  // Wait 5 seconds for the server to start sending,
            deadline: 60000, // but allow 1 minute for the file to finish loading.
        })
        .end(function (err, res) {
            if(err){
                Count = -1;
                GetAgin++
                if(GetAgin<5){
                    getCount()
                };
            }else{
                Count= res.text;
                if(Count==-1){
                    email.toEmail("获取提交总数失败！"+Count,"程序错误");
                    writeLog("获取提交总数失败！"+Count)
                    GetAgin++
                    if(GetAgin<5){
                        getCount()
                    };

                }else if(Count==0){
                    GetAgin=0
                    email.toEmail("提交数量为0！"+Count,"提醒");
                    writeLog("提交数量为0！"+Count)
                }else if(Count>0){
                    GetAgin=0
                    email.toEmail("今天提交总数："+Count,"通知");

                    var D=8-new Date().getHours();
                    if(D>0){
                        Num=Math.floor(Count/D)+mytool.rand(10,100);
                        secondNum=Math.floor(Num/60);
                        secondArr=getRandomArrayElements(rule1.second,secondNum);
                    }
                    writeLog("今天提交总数:"+Count)

                }else{
                    email.toEmail("获取总数未知问题！"+Count,"提醒");
                    writeLog("获取总数未知问题:"+Count)
                    GetAgin++
                    if(GetAgin<5){
                        getCount()
                    };
                }
            }
        });
}

function getRandomArrayElements(arr, count) {
    var shuffled = arr.slice(0), i = arr.length, min = i - count, temp, index;
    while (i-- > min) {
        index = Math.floor((i + 1) * Math.random());
        temp = shuffled[index];
        shuffled[index] = shuffled[i];
        shuffled[i] = temp;
    }
    return shuffled.slice(min);
}


function writeLog(err, type) {
    var str = "";
    if (typeof (err) == "object") {
        err.addtime = mytool.getNowFormatDate();
        str = JSON.stringify(err);
    } else {
        var _obj = {}
        _obj.msg = err;
        _obj.addtime = mytool.getNowFormatDate();
        str = JSON.stringify(_obj);
    }

    var t = "main";
    if (type) {
        t = type;
    }
    console.log(str);
    //  return;
    fs.appendFile("log/" + mytool.getNowFormatDate(1) + "-" + t + ".log", str + "\r\n", 'utf8', function (err) {
        if (err) throw err;
    });
}
